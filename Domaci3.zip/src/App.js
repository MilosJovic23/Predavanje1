
import "./style.css"
import Products from "./Components/Products"
import { useState } from "react";
let name ="Milos"

function clickOnButton(){
    console.log("works")
}

function App() {

    let [name,setName]=useState("Hello World")
    let [tax,setTax]=useState("20")


    return (

        <>

            <Products tax={tax}/>

            <button onClick={clickOnButton}>{name}</button>
            <input type="text" onInput={(e)=>setName(e.target.value)}/>
            <input placeholder="tax" type="text" onInput={(e)=>setTax(e.target.value)}/>

        </>

    );
}


export default App;