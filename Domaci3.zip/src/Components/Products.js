//
import { useState } from "react";


function Products(props){

    let [products,setProducts]=useState({
        "iPhone 14":1000,
        "iPhone 15":1250,
        "Samsung s23 ultra":1400})


    let [newProductName,setNewProductName]=useState();
    let [newProductPrice,setNewProductPrice]=useState()

    // 1. input  za unos podataka
    // 2. input za unos cene
    // 3. button za kreiranje proizvoda
    //
    function addProduct(){
        setProducts(prev=>({...prev,[newProductName]:parseInt(newProductPrice)}))
    }
    console.log(products)
    return(
        <>
            <button onClick={(e)=>setProducts({})}>delete</button>

            {Object.entries(products).map(([phone, price]) => {
                return <p>{phone}, price:${price} with tax:${calculateTax(price, props.tax)}</p>

            })}
            <div>
                <input type="text" placeholder="unesite ime proizvoda" onInput={(e)=>setNewProductName(e.target.value)}/>
                <input type="number" placeholder="unesite cenu proizvoda" onInput={(e)=>setNewProductPrice(e.target.value)}/>
                <button onClick={addProduct}>Add new products</button>
            </div>
        </>
    )

    function calculateTax(price, tax){
    return ((tax/100)*price)+price
}

}


export default Products